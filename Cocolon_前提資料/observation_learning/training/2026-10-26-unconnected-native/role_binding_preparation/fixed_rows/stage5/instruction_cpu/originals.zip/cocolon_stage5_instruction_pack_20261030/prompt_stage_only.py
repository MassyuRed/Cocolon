"""Candidate syntax correction for the existing five-stage offline experiment.

No model, decoder, teacher, receiver or acceptance changes. Original full-wire
syntax is archived separately; active root and row syntax describe this call.
"""
import copy
import json

VERSION = 'cocolon.stage5.stage_only_prompt.v1'
FORMAT = 'cocolon.cmee.fixed_rows_comparison.v1'
OLD_SYSTEM_DIRECTIVE = '出力形式は' + FORMAT + 'です。'
FIELDS = [['comparison_version', 'candidate_version', 'aliases', 'quotes'],
          ['claims', 'conflicts', 'core'], ['relations', 'schema', 'unknowns'],
          ['updates'], ['question', 'prose']]
ROW_NAMES = [['q'], ['claim', 'time', 'mode', 'polarity', 'pred', 'subject'],
             ['relation'], ['update'], ['prose', 'bind']]
FIELD_TYPES = {
    'comparison_version': 'JSON string: final comparison wire version',
    'candidate_version': 'JSON string: original named-wire version',
    'aliases': 'list of [alias_name, actual_identity] rows; each row exactly two strings',
    'quotes': 'list of q rows',
    'claims': 'list of claim rows; each claim contains its nested time/mode/polarity/pred/subject rows',
    'conflicts': 'JSON list', 'core': 'JSON string',
    'relations': 'list of relation rows', 'schema': 'JSON string',
    'unknowns': 'JSON list', 'updates': 'list of update rows',
    'question': 'null or original question JSON object', 'prose': 'one prose row',
}
VALUE_RULES = [
    'Every row is a JSON array in its listed field order, never an object.',
    'All remaining cells keep their original JSON types, including arrays, nulls and strings.',
    'All reference names, quotes, axes, IDs, update assignment/order and prose remain explicit model outputs.',
    'Do not shorten names, omit empty cells, infer values, auto-number IDs or copy a value from another cell.',
    'No row padding, JSON repair, coercion or semantic completion. The decoder restores fixed field names only.',
    'Invalid rows are rejected. Emit no Markdown, explanation or additional root wrapper.',
    'prior_adopted_interpretation is read-only context in the original named format, never this call output.',
    'Its aliases/quote names are local there; declare every used identity and quote in the current stage1 aliases/quotes.',
    'Every ev contains output quote IDs. ur lists only this output updates.$id, never relation or gap IDs.',
    'updates.prior uses the snapshot alias @p0, not a source alias.',
    'The original named-wire version and candidate schema value must be explicitly emitted in stages1 and3.',
    'Updates are emitted in stage4, before prose in stage5; other stages never emit those fields.',
    'observation, reception and update_note are Japanese strings addressed to the person in stage5.',
    'Each bind row has cr,rr,section, optionally a fourth ur cell. cr/rr/ur retain their original lists.',
]

def compact(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)

def build_messages(base_messages, stage, previous):
    if len(base_messages) != 2 or [m['role'] for m in base_messages] != ['system', 'user']:
        raise ValueError('base_messages_shape')
    if type(stage) is not int or not 1 <= stage <= 5 or [p['stage'] for p in previous] != list(range(1, stage)):
        raise ValueError('previous_order')
    original = json.loads(base_messages[1]['content'])
    spec = original['output_spec']
    system = base_messages[0]['content']
    if system.count(OLD_SYSTEM_DIRECTIVE) != 1:
        raise ValueError('unexpected_original_system_directive')
    system = system.replace(OLD_SYSTEM_DIRECTIVE, '')
    names = FIELDS[stage - 1]
    # Source material and adopted prior remain exact. Only output syntax moves.
    request = {k: copy.deepcopy(v) for k, v in original.items() if k not in ('output_spec', 'model_output_format')}
    semantics = {k: copy.deepcopy(v) for k, v in spec.items() if k not in ('notation', 'output_types', 'shape')}
    rows = {k: copy.deepcopy(spec['shape'][k]) for k in ROW_NAMES[stage - 1]}
    contract = dict(version=VERSION, stage=stage, stage_count=5,
                    root_fields_in_order=names, root_arity=len(names),
                    field_types={k: FIELD_TYPES[k] for k in names}, row_fields=rows,
                    emit_only_this_stage=True, previous_stages_are_unadopted_candidates=True,
                    previous_candidates_are_not_user_sources=True,
                    no_earlier_revision=True, no_completion=True, no_repair=True)
    active = ('これは5区間候補の第' + str(stage) + '区間です。'
              '今回の出力は' + compact(names) + 'の順の' + str(len(names)) + '要素を持つJSON配列一つだけです。'
              'stage_output_contractの構文だけで出力してください。完成packet全体のrootやcandidateの外枠を付けません。'
              'final_packet_semanticsは最終結合packet全体に対する意味条件です。そこに他区間の生成命令があっても、'
              '今回の出力欄を増やす指示ではありません。全意味条件は保持し、今回担当の欄だけを生成します。'
              '過去の採用解釈と前段候補は本人の新しい発言ではありません。前段候補を根拠化したり書き換えたりしません。')
    payload = dict(original_request=request, stage_output_contract=contract,
                   value_rules=VALUE_RULES, final_packet_semantics=semantics,
                   final_format_reference=dict(model_output_format=original['model_output_format'],
                                               comparison_version=FORMAT,
                                               use='final assembly identity, not this call root shape'),
                   previous_candidate_stages=copy.deepcopy(previous))
    return [dict(role='system', content=active + '\n' + system), dict(role='user', content=compact(payload))]
