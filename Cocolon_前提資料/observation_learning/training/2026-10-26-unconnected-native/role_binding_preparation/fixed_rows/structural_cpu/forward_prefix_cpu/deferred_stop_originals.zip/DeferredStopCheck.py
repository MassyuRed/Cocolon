class DeferredStopCheck(StopCheck):
    """
    A deferred `StopCheck` that reports whether generation should stop, one step late, so the host never waits on the device.

    Reading `unfinished_sequences.max() == 0` blocks the host until the device has caught up, every step, leaving it unable to queue
    the next step meanwhile. Copying that flag asynchronously and reading it on the *following* step removes the stall. It costs one
    extra `forward` pass, whose results the caller undoes using the count returned by `finish`.
    Streaming needs the tokens themselves on the host, which is the same synchronization, so tokens are streamed one step behind.
    The extra token is never streamed: it is still in flight when the loop breaks, and `finish` drops it.
    """

    def __init__(
        self,
        input_ids: torch.LongTensor,
        max_length: int,
        cache: "Cache | None",
        cache_is_returned: bool,
        streamer: "BaseStreamer | None" = None,
    ):
        super().__init__(streamer)
        self.max_length = max_length
        # We only need to care about rollbacking the cache if we are going to return the Cache, i.e. if the user requested additional
        # outputs or if the user passed an explicit Cache object
        self.cache = cache if cache_is_returned else None
        if self.cache is not None:
            self.cache.activate_past_recording()
        pinned = input_ids.device.type == "cuda"
        self.slots = deque(
            (
                torch.zeros((), dtype=torch.bool, pin_memory=pinned),
                torch.zeros(input_ids.shape[0], dtype=torch.long, pin_memory=pinned),
                torch.Event(device=input_ids.device, blocking=True),
            )
            for _ in range(2)
        )
        self.is_first_step = True
        self.stop_reported = False

    @staticmethod
    def is_supported(device: torch.device, cache: "Cache | None", cache_is_returned: bool, is_assistant: bool) -> bool:
        """
        Whether the stop decision can safely be deferred by a step, in this decoding context.
        In general, we do not defer unless the device is `"mps"`, and if the user requests to return the `Cache`, we need this
        `Cache` to be able to rollback its states correctly, so that the last `forward` can be correctly reverted.
        """
        # Only mps for now, we should enable it for cuda if we observe perf gains - also skip if it's an assistant
        if device.type != "mps" or is_assistant:
            return False
        # Since this is called after prefill, if we still do not have any cache, it means we'll never have one
        if cache is None:
            return True
        # if we don't return the cache, we don't need to bother about activating past recording since it will be dropped anyway
        else:
            return cache.is_croppable or not cache_is_returned

    def __call__(self, unfinished_sequences: torch.Tensor, tokens: torch.Tensor, length: int) -> bool:
        should_stop, tokens_cpu, copy_done = self.slots[0]
        should_stop.copy_(unfinished_sequences.max() == 0, non_blocking=True)
        if self.streamer is not None:
            tokens_cpu.copy_(tokens, non_blocking=True)
        copy_done.record()

        self.slots.rotate()
        should_stop_before, tokens_cpu_before, copy_done_before = self.slots[0]
        copy_done_before.synchronize()
        if not self.is_first_step:
            if self.streamer is not None:
                self.streamer.put(tokens_cpu_before.clone())
            self.stop_reported = bool(should_stop_before)
        self.is_first_step = False
        stopping = self.stop_reported or (self.max_length is not None and length >= self.max_length)
        if not stopping and self.cache is not None:
            self.cache.crop(0)
        return stopping

    def finish(self) -> int:
        for *_, copy_done in self.slots:
            copy_done.synchronize()
        steps_to_undo = 1 if self.stop_reported else 0
        if self.streamer is not None and not steps_to_undo:
            _, tokens_cpu, _ = self.slots[1]
            self.streamer.put(tokens_cpu.clone())
        if self.cache is not None:
            self.cache.crop(-steps_to_undo)
            # We also need to deactivate past_recording, since we are giving the cache back to the user and it may lead to unneeded
            # memory spike on the next prefill
            for layer in self.cache.layers:
                if hasattr(layer, "record_past"):
                    layer.record_past = False
        return steps_to_undo
