"""One bounded continuation from saved d431; unchanged teachers, loss and CMEE."""
import argparse,gc,hashlib,importlib.util,json,math,os,random,signal,sys,time,traceback
from pathlib import Path
from unittest.mock import patch
sys.dont_write_bytecode=True
ROOT=Path('/workspace/cocolon_update_obligations_20261028')
OUTPUT=Path('/workspace/cocolon_aligned13_run_20261028')
INITIAL='d431a07ce227c05e81eca5afb9461d91cf8101d50af0d27ec1a81844ce8ac684'
IDS=['FT-BOOK-AFTER-ANSWER','FT-SHOP-AFTER-ANSWER']
ORDER=['TRAIN-SERVICE-CHAIR-01-INITIAL',IDS[0],'TRAIN-DAILY-CALM-01-INITIAL','TRAIN-SERVICE-CHAIR-01-CORRECTION',IDS[1],'TRAIN-SERVICE-CHAIR-02-INITIAL','TRAIN-DAILY-CALM-02-INITIAL','TRAIN-SERVICE-CHAIR-02-CORRECTION',IDS[0],'TRAIN-SERVICE-CHAIR-03-INITIAL','TRAIN-DAILY-CALM-03-INITIAL','TRAIN-SERVICE-CHAIR-03-CORRECTION',IDS[1]]
FIXED=dict(schema='cocolon.aligned_continuation13_once.v1',initial_adapter_sha256=INITIAL,api_commit='64c6cb1a41620fd2d7690e0b6f1af30ae0e624a4',pod_id='94a06hhxu51uy4',expected_gpu_name='NVIDIA RTX A5000',output_directory=str(OUTPUT),optimizer_steps=13,update_order=ORDER,before_calls=0,max_model_calls=2,case_ids=IDS,max_seconds=600,per_generation_seconds=180,gpu_hourly_usd=.28,max_process_usd=.047,learning_rate=1e-5,seed=20261024,gradient_clip=1.0,loss_extra_weight=15,adaptive_gamma=2.0,old9_original_ce=True,context_tokens=8192,optimizer_resume=False,retry=False,gpu_lifecycle_operations=0,sql_operations=0,product_credit=0,candidate_ready=False,automatic_progression=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v):
 temp=p.with_suffix(p.suffix+'.tmp');temp.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n');temp.replace(p)
def module(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
def validate(pack,execution=False):
 plan=json.loads((pack/'aligned13.plan.json').read_text())
 extra={'status','gpu_run_authorized','approval_basis','runner_sha256','cpu_check_sha256','eval_inputs_sha256','train_messages_sha256','loss_sha256','consumer_sha256'}
 assert set(plan)==set(FIXED)|extra
 for k,v in FIXED.items():assert type(plan[k]) is type(v) and plan[k]==v,k
 authorized=plan['status']=='AUTHORIZED_ONCE_BOUND'
 assert plan['status'] in ('PREPARED_AWAITING_FINAL_CPU_REVIEW','AUTHORIZED_ONCE_BOUND')
 assert type(plan['gpu_run_authorized']) is bool and plan['gpu_run_authorized']==authorized
 assert (authorized and type(plan['approval_basis']) is str and plan['approval_basis'].strip()) or (not authorized and plan['approval_basis'] is None)
 if execution and not authorized:raise ValueError('aligned13_authorization_required_before_output_or_model')
 assert sha(__file__)==plan['runner_sha256']
 for n,key in [('actual_cpu_check.json','cpu_check_sha256'),('eval_inputs.json','eval_inputs_sha256'),('train_messages.jsonl','train_messages_sha256'),('adaptive_loss.py','loss_sha256'),('consume_aligned13.py','consumer_sha256')]:assert sha(pack/n)==plan[key],n
 cpu=json.loads((pack/'actual_cpu_check.json').read_text())
 assert cpu['status']=='CPU_ALIGNED13_READY_NO_MODEL_EXECUTION' and cpu['optimizer_steps']==13 and len(cpu['changed_prompts'])==5
 assert cpu['teacher15_target_ids_unchanged'] and cpu['teacher15_meaning_body_adopted']
 assert all(sha(pack/n)==h for n,h in cpu['payload_sha256'].items())
 assert sha(ROOT/'restore_payload.json')==cpu['source_manifest_sha256']
 for f in json.loads((ROOT/'restore_payload.json').read_text())['files']:assert sha(ROOT/f['path'])==f['sha256'],f['path']
 assert sha(ROOT/'adapter/adapter_model.safetensors')==INITIAL
 return plan,cpu
def execute(pack,source):
 plan,cpu=validate(pack,True);assert len(source)==40 and all(c in '0123456789abcdef' for c in source)
 args=(Path('/proc')/str(os.getppid())/'cmdline').read_bytes().split(bytes([0]))
 assert args[0].rsplit(b'/',1)[-1]==b'timeout' and all(x in args for x in (b'--signal=TERM',b'--kill-after=10s',b'590s'))
 OUTPUT.mkdir(exist_ok=False);started=time.monotonic();deadline=started+600
 report=dict(status='STARTED_ONCE',source_commit=source,plan=plan,stage='preparing',optimizer_steps_started=0,optimizer_steps_completed=0,training_forwards_started=0,training_forwards_completed=0,model_loads_started=0,model_loads_completed=0,model_calls_started=0,model_calls_completed=0,calls=[],training_updates=0,retry=False,automatic_progression=False,product_credit=0,gpu_lifecycle_operations=0,sql_operations=0)
 model=None;optimizer=None;trainable=None;initial=None;ids=None;labels=None;value=None;original=None;generate=None;r=None
 def checkpoint():report['elapsed_seconds']=time.monotonic()-started;dump(OUTPUT/'run.json',report)
 def stop(*_):raise TimeoutError('aligned13_deadline_no_retry')
 signal.signal(signal.SIGALRM,stop);signal.signal(signal.SIGTERM,stop);signal.setitimer(signal.ITIMER_REAL,600);checkpoint()
 try:
  assert os.environ.get('HF_HUB_OFFLINE')==os.environ.get('TRANSFORMERS_OFFLINE')=='1'
  check=module('aligned13_saved_adapter_owner',ROOT/'check_adapter_cpu.py');r,owner,_,_=check.existing_loaders(ROOT)
  from transformers import AutoTokenizer,StoppingCriteria,StoppingCriteriaList
  import importlib.metadata,torch
  assert {n:importlib.metadata.version(n) for n in r.PINS}==r.PINS
  assert os.environ.get('RUNPOD_POD_ID')==plan['pod_id'] and torch.cuda.device_count()==1
  report['gpu']=r.gpu_profile(torch,{'minimum_free_gib':14});assert report['gpu']['name']==plan['expected_gpu_name']
  tok=AutoTokenizer.from_pretrained(r.MODEL,revision=r.REVISION,local_files_only=True,trust_remote_code=False)
  rows=r.read_jsonl(pack/'train_messages.jsonl');encoded={row['id']:r.encode_training(tok,row['messages'],context=8192)[0] for row in rows}
  byid={c['case_id']:c for c in json.loads((pack/'eval_inputs.json').read_text())};cases=[byid[cid] for cid in IDS]
  assert [c['max_new_tokens'] for c in cases]==[3712,3712]
  loss=module('aligned13_unchanged_adaptive_loss',pack/'adaptive_loss.py');torch.cuda.reset_peak_memory_stats()
  hashes=r.adapter_hashes(ROOT/'adapter');report.update(stage='loading_d431_trainable',model_loads_started=1);checkpoint()
  model,tensors=owner.load_expanded_adapter(r,ROOT/'adapter',hashes,trainable=True);report['model_loads_completed']=1;dump(OUTPUT/'initial_loaded_tensors.json',tensors)
  trainable=[(n,p) for n,p in model.named_parameters() if p.requires_grad];assert len(trainable)==len(tensors)==112
  initial={n:p.detach().cpu().clone() for n,p in trainable}
  random.seed(plan['seed']);torch.manual_seed(plan['seed']);torch.cuda.manual_seed_all(plan['seed'])
  model.config.use_cache=False;model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant':False});model.enable_input_require_grads();model.train()
  optimizer=torch.optim.AdamW([p for _,p in trainable],lr=plan['learning_rate'],weight_decay=0.)
  with (OUTPUT/'training.jsonl').open('x') as stream:
   for step,cid in enumerate(ORDER,1):
    assert time.monotonic()<deadline-5
    e=encoded[cid];ids=torch.tensor([e['input_ids']],dtype=torch.long,device='cuda:0');labels=torch.tensor([e['labels']],dtype=torch.long,device='cuda:0')
    optimizer.zero_grad(set_to_none=True);report.update(stage='training:'+cid,training_forwards_started=step);checkpoint()
    value=loss.teacher_loss(model,r,input_ids=ids,attention_mask=torch.ones_like(ids),labels=labels,encoded=e,adaptive=cid in IDS)
    report['training_forwards_completed']=step;assert torch.isfinite(value).item();value.backward()
    norm=float(torch.nn.utils.clip_grad_norm_([p for _,p in trainable],1.,error_if_nonfinite=True).cpu());assert math.isfinite(norm) and norm>0
    report['optimizer_steps_started']=step;checkpoint();optimizer.step();report.update(optimizer_steps_completed=step,training_updates=step)
    stream.write(json.dumps(dict(step=step,id=cid,loss=float(value.detach().cpu()),adaptive=cid in IDS,target_tokens=sum(x!=-100 for x in e['labels']),gradient_norm=norm))+'\n');stream.flush();checkpoint();ids=None;labels=None;value=None
  optimizer.zero_grad(set_to_none=True);optimizer=None
  assert all(torch.isfinite(p).all().item() for _,p in trainable)
  report['changed_tensors']=sum(not torch.equal(initial[n],p.detach().cpu()) for n,p in trainable);assert report['changed_tensors']>0
  model.save_pretrained(OUTPUT/'adapter',safe_serialization=True);report.update(stage='saved_before_nontraining_reload',adapter_sha256=r.adapter_hashes(OUTPUT/'adapter'));assert report['adapter_sha256']['adapter_model.safetensors']!=INITIAL;checkpoint()
  initial=None;trainable=None;model=None;gc.collect();torch.cuda.empty_cache()
  report.update(stage='loading_saved_inference_only',model_loads_started=2);checkpoint()
  model,tensors=owner.load_expanded_adapter(r,OUTPUT/'adapter',report['adapter_sha256'],trainable=False)
  assert len(tensors)==112 and not any(p.requires_grad for p in model.parameters());report['model_loads_completed']=2;dump(OUTPUT/'reloaded_tensors.json',tensors)
  for case in cases:
   assert time.monotonic()<deadline-5 and report['model_calls_started']<2
   stop_at=min(deadline,time.monotonic()+180);triggered=False;original=model.generate
   class Bounded(StoppingCriteria):
    def __call__(self,*a,**kw):
     nonlocal triggered
     triggered=time.monotonic()>=stop_at;return triggered
   def generate(*a,**kw):
    kw['stopping_criteria']=StoppingCriteriaList([*list(kw.get('stopping_criteria') or []),Bounded()]);return original(*a,**kw)
   report['model_calls_started']+=1;report['stage']='after:'+case['case_id'];checkpoint();path=OUTPUT/('after_'+case['case_id']+'.jsonl')
   with patch.object(model,'generate',generate):r.evaluate(model,tok,[case],path,{'context_tokens':8192,'max_new_tokens':3712},adapter_revision=report['adapter_sha256']['adapter_model.safetensors'])
   raw=r.read_jsonl(path);assert len(raw)==1;report['model_calls_completed']+=1;report['calls'].append(dict(case_id=case['case_id'],path=path.name,raw_sha256=sha(path),eos_reached=raw[0]['eos_reached'],timeout_triggered=triggered));checkpoint()
   assert not triggered and time.monotonic()<stop_at,'generation_timeout_no_retry'
  assert r.adapter_hashes(OUTPUT/'adapter')==report['adapter_sha256']
  report.update(status='RAW_COMPLETE_PENDING_CMEE_AND_BODY_REVIEW',stage='raw_complete',peak_allocated_bytes=torch.cuda.max_memory_allocated(),peak_reserved_bytes=torch.cuda.max_memory_reserved())
 except BaseException as exc:
  report.update(status='STOPPED_NO_RETRY',error_type=type(exc).__name__,reason=str(exc),traceback=traceback.format_exc())
  if model is not None and report['optimizer_steps_started']>0 and 'adapter_sha256' not in report:
   try:
    ids=None;labels=None;value=None;optimizer=None;gc.collect();model.save_pretrained(OUTPUT/'partial_adapter',safe_serialization=True);report.update(partial_adapter_sha256=r.adapter_hashes(OUTPUT/'partial_adapter'),partial_adapter_not_promoted=True)
   except BaseException as save_exc:report['partial_adapter_preservation_error']=str(save_exc)
 finally:
  original=None;generate=None;model=None;optimizer=None;trainable=None;initial=None;ids=None;labels=None;value=None;gc.collect()
  if 'torch' in sys.modules and sys.modules['torch'].cuda.is_initialized():sys.modules['torch'].cuda.empty_cache();report['post_release_allocated_bytes']=sys.modules['torch'].cuda.memory_allocated()
  try:
   assert validate(pack)[0]==plan;assert r is not None and r.adapter_hashes(ROOT/'adapter')==hashes;report['initial_d431_and_sources_unchanged']=True
   if 'adapter_sha256' in report:assert r.adapter_hashes(OUTPUT/'adapter')==report['adapter_sha256']
  except BaseException as exc:report.update(status='STOPPED_IDENTITY_UNVERIFIED_NO_RETRY',final_identity_error=str(exc))
  signal.setitimer(signal.ITIMER_REAL,0);report['processing_seconds']=time.monotonic()-started;report['process_cost_usd']=report['processing_seconds']*.28/3600;checkpoint()
 print(json.dumps({k:report.get(k) for k in ('status','optimizer_steps_completed','model_calls_completed','processing_seconds','process_cost_usd')}),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--pack',type=Path,required=True);p.add_argument('--execute',action='store_true');p.add_argument('--source-commit',default='');a=p.parse_args()
 if a.execute:execute(a.pack.resolve(),a.source_commit)
 else:plan,cpu=validate(a.pack.resolve());print('ALIGNED13_VALIDATED_NO_MODEL',len(plan['update_order']))
